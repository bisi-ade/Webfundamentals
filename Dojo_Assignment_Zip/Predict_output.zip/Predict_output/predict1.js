for(var num = 0; num < 15; num++){
    console.log(num);
}