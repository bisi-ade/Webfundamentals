for(var i = 1; i < 10; i+=2){
    if(i % 3 == 0){
        console.log(i);
    }
}