
    var sum = 0;
    for (var num = 1; num <= 5; num++){
        sum = sum + num;
        // console.log(" Num: "+num+ ", Sum: "+sum);

        console.log(`Num: ${num}, Sum: ${sum}`);
    }
    
