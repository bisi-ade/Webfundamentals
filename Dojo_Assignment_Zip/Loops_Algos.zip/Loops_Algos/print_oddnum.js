for (var i =1; i <= 20; i++) {
    if (i % 2 == 1) {
        console.log (i);
    }
    
}